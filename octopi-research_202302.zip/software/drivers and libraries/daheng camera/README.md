## step 1: install the camera driver
If you're using an arm-based platfrom (e.g. Nvidia Jetson), follow the instructions in the `Galaxy_Linux-armhf_Gige-U3_32bits-64bits_1.3.1911.9271`. If you're using a x86 platform, follow instructions in the `Galaxy_Linux-x86_Gige-U3_32bits-64bits_1.2.1911.9122` folder.

## step 2: install the python library
Follow instructions in the `Galaxy_Linux_Python_1.0.1905.9081` folder.
