cp octopi-research-malaria.desktop ~/.local/share/applications/
chmod u+x ~/.local/share/applications/octopi-research-malaria.desktop
cp ~/.local/share/applications/octopi-research-malaria.desktop ~/Desktop/