#ifndef CRC8_H_
#define CRC8_H_
#include<Arduino.h>

uint8_t crc8ccitt(const void *data, uint8_t n);

#endif /* CRC8_H_ */
